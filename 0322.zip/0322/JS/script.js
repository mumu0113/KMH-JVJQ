// for(let a = 1; a <= 5; a++) {  // 구구단 1 - 5단까지 //
//   document.write("<h2>" + "[" + a + "단]" + "</h2>");  
//   for(let b = 1; b <= 9; b++) {  // 1 ~ 9까지 곱하기 //
//     document.write(a + " x " + b + " = " + (a*b));
//     document.write("<br>");
//   };
// };


// let num = 1;
// let t = "<table border=1>";

// for(let i = 1; i <= 5; i++) {
//   t+="<tr>";
//   for(let k = 1; k <= 5; k++) {
//     t+="<td>" + num + "</td>"
//     num++;
//   }
//   t+="</tr>";
// }
// t+="</table>";
// document.write(t);
// console.log(t);


// let tv = new Object();  // 개발자가 만드는 객체
// tv.color = "white";     // tv => 객체 + "." + 속성값
// tv.price = 300000;
// tv.info = function() {  //function => 함수
//   document.write("tv 색상: " + this.color + "<br>");
//   document.write("tv 가격: " + tv.price + "<br>");
// };

// let car = {  //두번째 방법
//   color: "black",
//   price: 5000000,
//   info: function() {
//     document.write("car 색상: " + this.color + "<br>");
//     document.write("car 가격: " + car.price + "<br>"); 
//   }
// };

// document.write("<h1>car 객체 메서드 호출</h1>");
// car.info();
// document.write("<h1>tv 객체 메서드 호출</h1>");
// tv.info();


// let test = {
//   math: 50,
//   science: 100,
//   avg: function() {
//     return test.math + test.science
//   } 
// }

// document.write(test.avg());


// let com = {
//   math: 50,
//   science: 100,
//   avg: function() {
//     return this.math + this.science
//   } 
// }

// document.write(com.avg());


// let today = new Date();
// let nowMonth = today.getMonth()+1,   // getMonth는 기본적으로 -1 되어있음.
// nowDate = today.getDate(),
// nowDay = today.getDay();

// document.write("<h1>오늘 날짜 정보를 알려주세요.</h1>");
// document.write("현재 월: " + nowMonth, "<br>");
// document.write("현재 일: " + nowDate, "<br>");
// document.write("현재 요일: " + nowDay, "<br>");

// let open = new Date("2023/3/13");   // ("2023,3,13") 쉼표로도 가능.
// let theMonth = open.getMonth()+1,   // getMonth는 기본적으로 -1 되어있음.
// theDate = open.getDate();
// theDay = open.getDay();

// document.write("<h1>개강일 날짜 정보를 알려주세요.</h1>");
// document.write("개강일 몇 월: " + theMonth, "<br>");
// document.write("개강일 몇 일: " + theDate, "<br>");
// document.write("개강일 무슨 요일: " + theDay, "<br>");


// let today = new Date();
// let nowYear = today.getFullYear();

// let theDate = new Date(nowYear, 11, 31);
// let diffDate = theDate.getTime() - today.getTime();


// let result = Math.ceil(diffDate / (60 * 60 *24 * 1000));  // 하루를 밀리 초로 바꿔줘야함.  // Math.ceil => 소수점 첫째자리에서 올림.
// document.write(result + "일 남았습니다.");  


// let num = 2.1234;

// let maxNum = Math.max(10, 5, 8, 30),  // 최대값
// minNum = Math.min(10, 5, 8, 30),     // 최소값
// roundNum = Math.round(num),         // 반올림
// floorNum = Math.floor(num),        // 소수점 첫째자리에서 내림
// ceilNum = Math.ceil(num),         // 소수점 첫째자리에서 올림
// rndNum = Math.random(),          // 실수를 난수 형태로 바꿔서 나옴. (새로고침할때마다 바뀜)
// piNum = Math.PI;

// document.write(maxNum, "<br>");
// document.write(minNum, "<br>");
// document.write(roundNum, "<br>");
// document.write(floorNum, "<br>");
// document.write(ceilNum, "<br>");
// document.write(rndNum, "<br>");
// document.write(piNum, "<br>");


document.write("<h1>컴퓨터와 함께 하는 가위, 바위, 보 게임!</h1>");

let game = prompt("가위, 바위, 보 중 입력하세요.", "예. 가위");
let gameNum;
swich (game) {
  case "가위" :
    gameNum = 1; break;
  case "바위" :
    gameNum = 2; break;
  case "보" :
    gameNum = 3; break;
  default: alert("잘못 작성하셨습니다.");
    location.reload();  // 새로고침
}

let com = Math.ceil(Math.random()*3);
document.write("<img src=\"/img/math_img_"+ com +".jpg\">");

if(gameNum == com) {
  document.write("<img src=\"/img/game_1.jpg\">");
} else {
  document.write("<img src=\"/img/game_2.jpg\">");
}






