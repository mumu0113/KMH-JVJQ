// let num = 1;
// let num_2 = 10;

// /* 배열객체 */

// let d = new Array();  //첫번째 방법
// d[0] = 10;
// d[1] = "뚜뚜뚜";
// d[2] = true;

// let d = new Array(10, "뚜뚜뚜", "true");  //두번째 방법

// let d = [10, "뚜뚜뚜", "true"];  //세번째 방법



// let arr = [30, "따르릉" ,"true"];

// document.write("<h3>배열값 가져오기-1</h3>");
// document.write(arr[0], "<br>");
// document.write(arr[1], "<br>");
// document.write(arr[2], "<br>");

// document.write("<h3>배열값 가져오기-2</h3>");
// for(let i = 0; i < arr.length; i++) {
//   document.write(arr[i], "<br>");
// }

// document.write("<h3>배열값 가져오기-3</h3>");
// for(i in arr) {
//   document.write(arr[i],"<br>");
// }



// let arr_1 = ["사당", "교대", "방배", "강남"];
// let arr_2 = ["신사", "압구정", "옥수"];

// let result = arr_1.join("-");
// document.write(result, "<br>");

// result = arr_1.concat(arr_2);
// document.write(result, "<br>");

// result = arr_1.slice(1, 3);       // 1부터 3이전까지
// document.write(result, "<br>");

// arr_1.sort();                     // 오름차순(가나다라순)
// document.write(arr_1, "<br>");

// arr_2.reverse();                  // 거꾸로
// document.write(arr_2, "<br>");



// let greenArr = ["교대", "방배", "강남"];
// let yellowArr = ["미금", "정자", "수서"];

// greenArr.splice(2, 1, "서초", "역삼");    // 2부터 1개 삭제 후 새로운 데이터 삽입
// document.write(greenArr, "<br>");

// let data1 = yellowArr.pop();             // 마지막 인덱스값 삭제. 수서 삭제됨
// let data2 = yellowArr.shift();           // 배열 객체 첫번째 인덱스값 삭제. 미금 삭제됨

// yellowArr.push(data2);
// document.write(yellowArr, "<br>");

// yellowArr.unshift(data1);
// document.write(yellowArr, "<br>");



// let t = "Hello Thank you good luck to you";
// document.write(t.charAt(16), "<br>");
// document.write(t.indexOf("you"), "<br>");
// document.write(t.indexOf("you", 16), "<br>");
// document.write(t.lastIndexOf("you"), "<br>");
// document.write(t.lastIndexOf("you", 25), "<br>");
// document.write(t.match("luck"), "<br>");
// document.write(t.search("you"), "<br>");
// document.write(t.substr(21, 4), "<br>");
// document.write(t.substring(6, 12), "<br>");
// document.write(t.replace("you", "me"), "<br>");
// document.write(t.toLowerCase(), "<br>");
// document.write(t.toUpperCase(), "<br>");
// document.write(t.length, "<br>");

// let s = t.split(" ");
// document.write(s[0], "<br>");
// document.write(s[4], "<br>");
// let str = "A";
// let k = str.charCodeAt(0);
// document.write(k, "<br>");  //아스키코드
// document.write(String.fromCharCode(65), "<br>");



// let userName = prompt("당신의 영문 이름은?");
// let upperName = userName.toUpperCase();
// document.write(upperName, "<br>"); 

// let userNum = prompt("당신의 연락처는?", "번호만 입력하세요.");
// let result = userNum.substring(0, userNum.length-4) + "****";
// document.write(result, "<br>");



// let userEmail = prompt("당신의 이메일 주소는?", "");
// let arrUrl = [".co.kr", ".com", ".net", "or.kr", "go.kr"];

// let check1 = false;
// let check2 = false;

// if(userEmail.indexOf("@") > 0) {
//   check1 = true;
// }
// for(let i = 0; i < arrUrl.length; i++) {
//   if(userEmail.indexOf(arrUrl[i]) > 0) {
//     check2 = true;
//   }
// }
// if(check1 && check2) {
//   document.write(userEmail);
// } else {
//   alert("이메일 형식이 잘못되었습니다.");
// }



// window.open("https://www.naver.com", "NAVER", "width=1920", "height=1080", "left=50", "top=10", "scrollbarse=no");


// confirm("정말로 삭제하시겠습니까?");



const hour = document.querySelector('.hour');
const min = document.querySelector('.min');
const sec = document.querySelector('.sec');

function clock() {
  const now = new Date();

  hour.innerText = now.getHours();
  min.innerText = now.getMinutes();
  sec.innerText = now.getSeconds();
}

setInterval(clock, 1000);







