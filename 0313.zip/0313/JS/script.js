let str = "<table border='1'>";
    str += "<tr>";
    str += "<td>1</td><td>2</td>";
    str += "</tr>"
    str += "</table>";
    document.write(str);