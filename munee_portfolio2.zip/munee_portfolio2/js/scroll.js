let isActive = false

$("main").on("scroll", function () {
  // 현재 main 스크롤 위치
  // console.log($(this).scrollTop())

  if (!isActive) {
    const offsetY = $(".skill").offset().top - window.innerHeight
  
    if (offsetY < 0) {
      $(".skill").addClass("active")
      isActive = true
    }
  }

})