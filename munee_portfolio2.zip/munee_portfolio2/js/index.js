/** swiper */
const projectSwiper = new Swiper(".project-swiper", {
  loop: true,
  slidesPerView: "auto",
  spaceBetween: 80,
  centeredSlides: true,
  navigation: {
    nextEl: ".swiper-button-next",
    prevEl: ".swiper-button-prev",
  },
});

const likeSwiper = new Swiper(".like-swiper", {
  loop: true,
  effect: "coverflow",
  slidesPerView: "auto",
  spaceBetween: 60,
  centeredSlides: true,
  coverflowEffect: {
    rotate: 45,
    stretch: 0,
    depth: 100,
    slideShadows: false,
  },
});

const artworkSwiper = new Swiper(".artwork-swiper", {
  slidesPerView: 3,
  grid: {
    rows: 2,
  },
  spaceBetween: 30,
  pagination: {
    el: ".artwork-pagination",
    clickable: true,
  },
});

// selector
const gnbItems = document.querySelectorAll(".gnb ul li span");
const contactTextarea = document.querySelector("#contact-textarea");
const textareaPlaceholder = document.querySelector("#textarea-placeholder");
const modal = document.querySelector(".modal");
const modalImage = document.querySelector(".modal-image");
const closeButton = document.querySelector(".modal .close-button");
const artworkSliders = document.querySelectorAll(
  ".artwork-swiper .swiper-slide"
);

contactTextarea.addEventListener("focus", () => {
  textareaPlaceholder.style.opacity = 0;
});

contactTextarea.addEventListener("blur", (ev) => {
  if (!ev.target.value) {
    textareaPlaceholder.style.opacity = 1;
  }
});

gnbItems.forEach((span) => {
  span.addEventListener("click", (ev) => {
    const id = "#" + ev.target.dataset.section;
    const section = document.querySelector(id);

    if (section) {
      const main = document.querySelector("main");
      main.scrollTop = section.offsetTop;
    }
  });
});

artworkSliders.forEach((slider) => {
  slider.addEventListener("click", (ev) => {
    const image = ev.target.style.backgroundImage;
    const [_, src] = image.match(/^url\("(.+)"\)$/);

    modalImage.src = src;
    modal.classList.add("show");

    // 가상 요소 생성
    const imageElement = document.createElement("img");

    // 경로 적용
    imageElement.src = src;

    const width = imageElement.naturalWidth;
    const height = imageElement.naturalHeight;

    const moreThenWidth = width > height;

    // 가상 요소 제거
    imageElement.remove();

    if (moreThenWidth) {
      modalImage.style.width = width > window.innerWidth ? "80%" : "";
      modalImage.style.height = "";
    } else {
      modalImage.style.height = height > window.innerHeight ? "80%" : "";
      modalImage.style.width = "";
    }

    modalImage.setAttribute("src", src);
    modal.classList.add("show");
  });
});

// modal
closeButton.addEventListener("click", () => {
  modal.classList.remove("show");
});
