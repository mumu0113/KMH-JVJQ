const nav = document.querySelector('.nav');
const header = document.querySelector('.header');

nav.addEventListener('mouseover', ()=>{
    header.style='height:250px'
})

header.addEventListener('mouseleave', ()=>{
    header.style='height:0';
})