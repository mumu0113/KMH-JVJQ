<?php if (!defined('_GNUBOARD_')) exit;

add_stylesheet('<link rel="stylesheet" href="'.$board_skin_url.'/style.css">', 0);

// 제목 자동생성
$subject = date("Y-m-d H:i:s");


// 문의분류 재생성 [공지]제거
$is_category = false;
if ($board['bo_use_category']) {
    $category_list = explode('|',$board['bo_category_list']);
    $is_category = true;
}



//날짜
include_once(G5_PLUGIN_PATH.'/jquery-ui/datepicker.php');
// if (empty($write['wr_1'])) $write['wr_1'] = G5_TIME_YMD;


// 개인정보 처리방침 HTML 처리
$cfg = [];
for($idx=1; $idx<=10; $idx++) {
    $key = 'bo_'.$idx.'_subj';
    if($board[$key]) $cfg[$board[$key]] = $board['bo_'.$idx];
}
$privacy_html = '';
if($cfg['개인정보처리방침']) {
    $privacy_html = file_get_contents($board_skin_path . '/privacy.html');
    foreach (explode('|',$cfg['개인정보처리방침']) as $idx=>$v) {
        $privacy_html = str_replace("{{{$idx}}}", $v, $privacy_html);
    }
}

// 캡챠 무조건 사용하도록 하기
//$is_use_captcha = true;
//$captcha_html = captcha_html();
//$captcha_js   = chk_captcha_js();



 

// add_stylesheet('css 구문', 출력순서); 숫자가 작을 수록 먼저 출력됨

add_stylesheet('<link rel="stylesheet" href="'.$board_skin_url.'/style.css">', 0);

add_javascript(G5_POSTCODE_JS, 0); //다음 주소 js

// 주소입력

$wr5 = explode('|',$write['wr_5']);

$ex_zip  = $wr5[0];

$ex_addr1  = $wr5[1];

$ex_addr2  = $wr5[2];

$ex_addr3  = $wr5[3];

$ex_jibeon  = $wr5[4];



if ($w == '') $secret_checked = 'checked';

/*
$name = '홍길동';
$email = 'sample@sample.com';
$wr_1 = '개발팀';
$wr_2 = '팀장';
$wr_content = '안녕하세요';
//*/
?>
<form name="fwrite" id="fwrite" action="<?php echo $action_url ?>"
      onsubmit="return fwrite_submit(this);"
      method="post" enctype="multipart/form-data" autocomplete="off">
    <input type="hidden" name="uid" value="<?php echo get_uniqid(); ?>">
    <input type="hidden" name="w" value="<?php echo $w ?>">
    <input type="hidden" name="bo_table" value="<?php echo $bo_table ?>">
    <input type="hidden" name="wr_id" value="<?php echo $wr_id ?>">
    <input type="hidden" name="sca" value="<?php echo $sca ?>">
    <input type="hidden" name="sfl" value="<?php echo $sfl ?>">
    <input type="hidden" name="stx" value="<?php echo $stx ?>">
    <input type="hidden" name="spt" value="<?php echo $spt ?>">
    <input type="hidden" name="sst" value="<?php echo $sst ?>">
    <input type="hidden" name="sod" value="<?php echo $sod ?>">
    <input type="hidden" name="page" value="<?php echo $page ?>">
    <input type="hidden" name="wr_subject" value="<?php echo $subject ?>">
    <input type="hidden" name="wr_content" value="상담 문의가 접수되었습니다.">

    <!--
    폼메일 입력 구조를 정의합니다.
    입력받을 데이터를 name|항목이름 순으로 입력합니다.
    -->
    <input type="hidden" name="contents_info[]" value="wr_name|성함">
    <input type="hidden" name="contents_info[]" value="wr_email|이메일">
    <input type="hidden" name="contents_info[]" value="wr_1|성별">
    <input type="hidden" name="contents_info[]" value="wr_2|연락처">
    <input type="hidden" name="contents_info[]" value="wr_3|생년월일">
    <input type="hidden" name="contents_info[]" value="wr_4|휴대폰">
    <input type="hidden" name="contents_info[]" value="wr_5|주소/우편번호">
    <input type="hidden" name="contents_info[]" value="wr_6|기본주소">
    <input type="hidden" name="contents_info[]" value="wr_7|상세주소">
    <input type="hidden" name="contents_info[]" value="wr_8|참고항목">
    <input type="hidden" name="contents_info[]" value="wr_9|전공">
    <input type="hidden" name="contents_info[]" value="wr_10|실무경력">
    <input type="hidden" name="contents_info[]" value="wr_11|최종학력">
    <input type="hidden" name="contents_info[]" value="wr_12|타자격증 취득">
    <input type="hidden" name="contents_info[]" value="wr_13|자격증 유무">
    <input type="hidden" name="contents_info[]" value="wr_14|실내건축자격증">
    <input type="hidden" name="contents_info[]" value="wr_15|강의지점">
    <input type="hidden" name="contents_info[]" value="wr_16|스케치 과정">
    <input type="hidden" name="contents_info[]" value="wr_17|강의지점">
    <input type="hidden" name="contents_info[]" value="wr_18|site방문경로">
    <input type="hidden" name="contents_info[]" value="wr_19|상담문의">
    <input type="hidden" name="contents_info[]" value="wr_20|비밀번호">
    <input type="hidden" name="contents_info[]" value="wr_21|전산응용 과정">
    <input type="hidden" name="contents_info[]" value="wr_22|강의지점">
    <input type="hidden" name="contents_info[]" value="wr_23|스케치업 과정">
    <input type="hidden" name="contents_info[]" value="wr_24|강의지점">
    <input type="hidden" name="contents_info[]" value="wr_25|CAD 과정">
    <input type="hidden" name="contents_info[]" value="wr_26|강의지점">
    <!--<input type="hidden" name="contents_info[]" value="ca_name|문의종류">
    <input type="hidden" name="contents_info[]" value="wr_content|문의내용">-->


    <section id="formmail-write">
        <?php if($is_admin) {?>
        <a href="<?php echo get_pretty_url($bo_table)?>" class="check-list">문의내역 확인</a>
        <?php }?>

        <script>

        $(document).ready(function(){
            $('#wr_2').keyup(function(){
                var regNumber = /^[0-9]*$/;
                var input = $('#wr_2').val();
                console.log(input);
                if(!regNumber.test(input)){
                    alert("숫자만 입력가능합니다");
                    $('#wr_2').val(input.replace(/[^0-9]/g , ""));
                }
            });
        });

        $(document).ready(function(){
            $('#wr_3').keyup(function(){
                var regNumber = /^[0-9]*$/;
                var input = $('#wr_3').val();
                console.log(input);
                if(!regNumber.test(input)){
                    alert("숫자만 입력가능합니다");
                    $('#wr_3').val(input.replace(/[^0-9]/g , ""));
                }
            });
        });

        $(document).ready(function(){
            $('#wr_4').keyup(function(){
                var regNumber = /^[0-9]*$/;
                var input = $('#wr_4').val();
                console.log(input);
                if(!regNumber.test(input)){
                    alert("숫자만 입력가능합니다");
                    $('#wr_4').val(input.replace(/[^0-9]/g , ""));
                }
            });
        });

        </script>
            <table class="form-body" frame=void>
                <tbody class="form-group col4">
                    <tr>
                    <div class="classtable">내일배움카드제 신청서</div>
                    </tr>
                    <tr>
                        <td class="name_wrap">
                            <label class="name_title" for="wr_name">성함</label>
                        </td>
                        <td class="text_box1" colspan="2">
                            <input type="text" name="wr_name" value="<?php echo $member['mb_name']?>" id="wr_name" required class="form-control required" size="20" maxlength="20">
                        </td>

                        <td class="name_wrap">
                            <label class="name_title" for="wr_email">이메일</label>
                        </td>
                        <td class="text_box1">
                            <input type="text" name="wr_email" value="<?php echo $member['mb_email']?>" id="wr_email" class="form-control email required" size="30" maxlength="100">
                        </td>
                    </tr>
                    <?php
                    //이메일 검사
                    if($check_email==true)
                    {echo $check_email;}
                    ?>


                    <tr>
                        <td class="name_wrap">
                            <label class="name_title" for="wr_3">생년월일</label>
                        </td>
                        <td class="text_box1" colspan="4">
                            <input type="text" style="width: 30%;" name="wr_3" value="<?php echo $wr_2 ?>" id="wr_3" required class="form-control required" size="10" maxlength="20" required/>
                        </td>
                    </tr>


                
                    <tr>
                        <td class="name_wrap">
                            <label class="name_title" for="wr_2">연락처</label>
                        </td>
                        <td class="text_box1" colspan="2">
                            <input type="text" style="width: 70%;" name="wr_2" value="<?php echo $wr_2 ?>" id="wr_2" required class="form-control required" size="10" maxlength="20" required/>
                        </td>

                        <td class="name_wrap">
                            <label class="name_title" for="wr_4">휴대폰</label>
                        </td>
                        <td class="text_box1">
                            <input type="text" name="wr_4" value="<?php echo $wr_4?>" id="wr_4" class="form-control" size="10" maxlength="20">
                        </td>
                    </tr>



                
                    <tr>
                        <th class="name_wrap">
                            <label class="name_title" for="wr_5">주소</label>
                        </th>
                        <td class="text_box1" colspan="4">
                            <label for="ex_zip" class="sound_only">우편번호</label>
                            <input type="text" name="wr_5" value="<?php echo $wr_5; ?>" id="wr_5"  class="frm_input form-control  required" style="width: 20%;" size="6" maxlength="6" required/>
                            <button type="button" class="btn_frmline" onclick="win_zip('fwrite', 'wr_5', 'wr_6', 'wr_7', 'wr_8');">주소 검색</button><br>

                            <input type="text" name="wr_6" style="width: 80%; margin-top: 15px;" value="<?php echo $wr_6; ?>" id="wr_6" class="frm_input form-control frm_address required" size="50" required/>
                            <label for="ex_addr1">기본주소</label><br>

                            <input type="text" name="wr_7" style="width: 80%; margin-block: 15px;" value="<?php echo $wr_7; ?>" id="wr_7" class="frm_input form-control frm_address" size="50">
                            <label for="ex_addr2">상세주소</label><br>

                            <input type="text" name="wr_8" style="width: 80%;" value="<?php echo $wr_8; ?>" id="wr_8" class="frm_input form-control frm_address" size="50" readonly="readonly">
                            <label for="ex_addr3">참고항목</label>
                            
                            <!--<input type="hidden" name="wr_14" value="<?//php echo $wr_5; ?>">-->
                        </td>
                    </tr>
                


                    <tr>
                        <td class="name_wrap">
                            <label class="name_title" for="wr_9">전공</label>
                        </td>
                        <td colspan="2" class="text_box1">
                            <label>
                                <input type="text" style="width: 70%;" name="wr_9" value="<?php echo $wr_9 ?>" id="wr_9" class="form-control required" size="10" maxlength="20" required>
                                과
                            </label>
                        </td>

                        <td class="name_wrap">
                            <label class="name_title" for="wr_10">실무경력</label>
                        </td>
                        <td class="text_box1">
                            <label>
                                <input type="text" name="wr_10" id="wr_10" value="<?php echo $wr_10 ?>" id="wr_10" class="form-control required" size="10" maxlength="20" required>
                            </label>
                        </td>
                    </tr>


                    <tr>
                        <td class="name_wrap">
                            <label class="name_title" for="wr_11">최종학력</label>
                        </td>        
                        <td class="check_wrap1" colspan="4">
                            <label for="wr_11_1" style="padding-inline: 10px;">
                                <input type="radio" name="wr_11" id="wr_11_1" class="required" value="고등학교 졸업" required>고등학교 졸업
                            </label>
                    
                            <label for="wr_11_2" style="padding-inline: 10px;">
                                <input type="radio" name="wr_11" id="wr_11_2" class="required" value="2, 3년제 대학 졸업" required>2, 3년제 대학 졸업
                            </label>

                            <label for="wr_11_3" style="padding-inline: 10px;">
                                <input type="radio" name="wr_11" id="wr_11_3" class="required" value="4년제 대학 졸업" required>4년제 대학 졸업
                            </label>

                            <label for="wr_11_4" style="padding-inline: 10px;">
                                <input type="radio" name="wr_11" id="wr_11_4" class="required" value="대학원 이상" required>대학원 이상
                            </label>
                        </td>
                    </tr>

                    
                    <tr>
                        <td class="name_wrap">
                            <label class="name_title" for="wr_12">타자격증 취득</label>
                        </td>
                        <td colspan="2" class="text_box1">
                            <label>
                                <input type="text" name="wr_12" style="width: 70%;" value="<?php echo $wr_12 ?>" id="wr_12" class="form-control" size="10" maxlength="20">
                            </label>
                        </td>

                        <td class="name_wrap">
                            <label class="name_title" for="wr_13">자격증 유무</label>
                        </td>
                        <td class="check_wrap1">
                            <label>
                                <input type="radio" name="wr_13" id="wr_13" class="required" value="있음" required/>있음
                            </label>
                            <label>
                                <input type="radio" name="wr_13" id="wr_13" class="required" value="없음" required/>없음
                            </label>
                        </td>
                    </tr>
            



                    <tr>
                        <td class="classtable" colspan="5">
                            수강과목 & 강의지점
                        </td>
                    </tr>

                    <tr>
                        <td class="name_wrap">
                            <label class="name_title" for="wr_14" rowspan="2">실내건축자격증</label>
                        </td>
                        <td class="check_wrap1" colspan="2">
                            <?php $check1 = explode(", ", $write['wr_14']); ?>
                            <label for="wr_14_1" style="padding-inline: 10px; width: 17%;">
                                <input type="checkbox" name="check1[]" id="wr_14_1" value="기사"<?php echo in_array("기사", $check1) ? ' checked="checked"' : '' ?> class="required">기사
                            </label>
                            <label for="wr_14_2" style="padding-inline: 10px; width: 17%;">
                                <input type="checkbox" name="check1[]" id="wr_14_2" value="산업기사"<?php echo in_array("산업기사", $check1) ? ' checked="checked"' : '' ?> class="required">산업기사
                            </label>
                        </td>


                        <td class="name_wrap">
                            <label class="name_title" for="wr_15">강의지점</label>
                        </td>
                        
                        <td class="check_wrap1" colspan="4">
                            <label>
                                <input type="radio" name="wr_15" id="wr_15" class="required" value="영등포점" required/>영등포점
                            </label>
                            <label>
                                <input type="radio" name="wr_15" id="wr_15" class="required" value="강남역점" required/>강남역점
                            </label>
                            <label>
                                <input type="radio" name="wr_15" id="wr_15" class="required" value="X" required/>X
                            </label>
                        </td>
                    </tr>


                    <tr>
                        <td class="name_wrap">
                            <label class="name_title" for="wr_21" rowspan="2">전산응용 과정</label>
                        </td>
                        <td class="check_wrap1" colspan="2">
                            <?php $check2 = explode(", ", $write['wr_21']); ?>
                            <label for="wr_21_1" style="padding-inline: 10px; width: 17%;">
                                <input type="checkbox" name="check2[]" id="wr_21_1" value="수강희망"<?php echo in_array("수강희망", $check2) ? ' checked="checked"' : '' ?> class="required">수강희망
                            </label>
                        </td>

                        <td class="name_wrap">
                            <label class="name_title" for="wr_22">강의지점</label>
                        </td>
                        
                        <td class="check_wrap1" colspan="4">
                            <label>
                                <input type="radio" name="wr_22" id="wr_22" class="required" value="영등포점" required/>영등포점
                            </label>
                            <!--<label>
                                <input type="radio" name="wr_17" id="wr_17" class="required" value="강남역점" required/>강남역점
                            </label>-->
                            <label>
                                <input type="radio" name="wr_22" id="wr_22" class="required" value="X" required/>X
                            </label>
                        </td>
                    </tr>


                    <tr>
                        <td class="name_wrap">
                            <label class="name_title" for="wr_23" rowspan="2">스케치업 과정</label>
                        </td>
                        <td class="check_wrap1" colspan="2">
                            <?php $check3 = explode(", ", $write['wr_23']); ?>
                            <label for="wr_23_1" style="padding-inline: 10px; width: 17%;">
                                <input type="checkbox" name="check3[]" id="wr_23_1" value="실내"<?php echo in_array("실내", $check3) ? ' checked="checked"' : '' ?> class="required">실내
                            </label>
                            <label for="wr_23_2" style="padding-inline: 10px; width: 17%;">
                                <input type="checkbox" name="check3[]" id="wr_23_2" value="건축"<?php echo in_array("건축", $check3) ? ' checked="checked"' : '' ?> class="required">건축
                            </label>
                            <label for="wr_23_3" style="padding-inline: 10px; width: 17%;">
                                <input type="checkbox" name="check3[]" id="wr_23_3" value="조경"<?php echo in_array("조경", $check3) ? ' checked="checked"' : '' ?> class="required">조경
                            </label>
                        </td>


                        <td class="name_wrap">
                            <label class="name_title" for="wr_24">강의지점</label>
                        </td>
                        
                        <td class="check_wrap1" colspan="4">
                            <label>
                                <input type="radio" name="wr_24" id="wr_24" class="required" value="영등포점" required/>영등포점
                            </label>
                            <label>
                                <input type="radio" name="wr_24" id="wr_24" class="required" value="X" required/>X
                            </label>
                        </td>
                    </tr>


                    <tr>
                        <td class="name_wrap">
                            <label class="name_title" for="wr_16" rowspan="2">스케치 과정</label>
                        </td>
                        <td class="check_wrap1" colspan="2">
                            <?php $check4 = explode(", ", $write['wr_16']); ?>
                            <label for="wr_16_1" style="padding-inline: 10px; width: 17%;">
                                <input type="checkbox" name="check4[]" id="wr_16_1" value="실내"<?php echo in_array("실내", $check4) ? ' checked="checked"' : '' ?> class="required">실내
                            </label>
                            <label for="wr_16_2" style="padding-inline: 10px; width: 17%;">
                                <input type="checkbox" name="check4[]" id="wr_16_2" value="건축"<?php echo in_array("건축", $check4) ? ' checked="checked"' : '' ?> class="required">건축
                            </label>
                            <label for="wr_16_3" style="padding-inline: 10px; width: 17%;">
                                <input type="checkbox" name="check4[]" id="wr_16_3" value="조경"<?php echo in_array("조경", $check4) ? ' checked="checked"' : '' ?> class="required">조경
                            </label>
                        </td>


                        <td class="name_wrap">
                            <label class="name_title" for="wr_17">강의지점</label>
                        </td>
                        
                        <td class="check_wrap1" colspan="4">
                            <label>
                                <input type="radio" name="wr_17" id="wr_17" class="required" value="영등포점" required/>영등포점
                            </label>
                            <label>
                                <input type="radio" name="wr_17" id="wr_17" class="required" value="강남역점" required/>강남역점
                            </label>
                            <label>
                                <input type="radio" name="wr_17" id="wr_17" class="required" value="X" required/>X
                            </label>
                        </td>
                    </tr>


                    <tr>
                        <td class="name_wrap">
                            <label class="name_title" for="wr_25" rowspan="2">CAD 과정</label>
                        </td>
                        <td class="check_wrap1" colspan="2">
                            <?php $check4 = explode(", ", $write['wr_25']); ?>
                            <label for="wr_25_1" style="padding-inline: 10px; width: 17%;">
                                <input type="checkbox" name="check5[]" id="wr_25_1" value="실내"<?php echo in_array("실내", $check4) ? ' checked="checked"' : '' ?> class="required">실내
                            </label>
                            <label for="wr_25_2" style="padding-inline: 10px; width: 17%;">
                                <input type="checkbox" name="check5[]" id="wr_25_2" value="건축"<?php echo in_array("건축", $check4) ? ' checked="checked"' : '' ?> class="required">건축
                            </label>
                            <label for="wr_25_3" style="padding-inline: 10px; width: 17%;">
                                <input type="checkbox" name="check5[]" id="wr_25_3" value="조경"<?php echo in_array("조경", $check4) ? ' checked="checked"' : '' ?> class="required">조경
                            </label>
                        </td>


                        <td class="name_wrap">
                            <label class="name_title" for="wr_26">강의지점</label>
                        </td>
                        
                        <td class="check_wrap1" colspan="4">
                            <label>
                                <input type="radio" name="wr_26" id="wr_26" class="required" value="영등포점" required/>영등포점
                            </label>
                            <label>
                                <input type="radio" name="wr_26" id="wr_26" class="required" value="강남역점" required/>강남역점
                            </label>
                            <label>
                                <input type="radio" name="wr_26" id="wr_26" class="required" value="X" required/>X
                            </label>
                        </td>
                    </tr>

                    
                    <tr>
                        <td class="name_wrap" style="padding: 30px;">
                            <label class="name_title" for="wr_18">site방문경로</label>
                        </td>
                        <td class="check_wrap1" colspan="4">
                            <?php $check6 = explode(", ", $write['wr_18']); ?>
                            <label for="wr_18_1" style="padding-inline: 10px; width: 17%;">
                                <input type="checkbox" name="check6[]" id="wr_18_1" value="소개"<?php echo in_array("소개", $check6) ? ' checked="checked"' : '' ?> class="required">소개
                            </label>

                            <label for="wr_18_2" style="padding-inline: 10px;width: 23%;">
                                <input type="checkbox" name="check6[]" id="wr_18_2" value="본원출판도서"<?php echo in_array("본원출판도서", $check6) ? ' checked="checked"' : '' ?> class="required">본원출판도서
                            </label>

                            <label for="wr_18_3" style="padding-inline: 10px;width: 22%;">
                                <input type="checkbox" name="check6[]" id="wr_18_3" value="인터넷"<?php echo in_array("인터넷", $check6) ? ' checked="checked"' : '' ?> class="required">인터넷
                            </label>

                            <label for="wr_18_4" style="padding-inline: 10px;width: 22%;">
                                <input type="checkbox" name="check6[]" id="wr_18_4" value="포스터"<?php echo in_array("포스터", $check6) ? ' checked="checked"' : '' ?> class="required">포스터
                            </label>

                            <label for="wr_18_5" style="padding-inline: 10px; width: 17%;">
                                <input type="checkbox" name="check6[]" id="wr_18_5" value="전화번호부"<?php echo in_array("전화번호부", $check6) ? ' checked="checked"' : '' ?> class="required">전화번호부
                            </label>

                            <label for="wr_18_6" style="padding-inline: 10px;width: 23%;">
                                <input type="checkbox" name="check6[]" id="wr_18_6" value="전단지"<?php echo in_array("전단지", $check6) ? ' checked="checked"' : '' ?> class="required">전단지
                            </label>

                            <label for="wr_18_7" style="padding-inline: 10px;width: 22%;">
                                <input type="checkbox" name="check6[]" id="wr_18_7" value="신문"<?php echo in_array("신문", $check6) ? ' checked="checked"' : '' ?> class="required">신문
                            </label>

                            <br>

                            <label for="wr_18_8" style="padding-inline: 10px;width: 22%;">
                                <input type="checkbox" name="check6[]" id="wr_18_8" value="월간지"<?php echo in_array("월간지", $check6) ? ' checked="checked"' : '' ?> class="required">월간지
                            </label>
                            
                            <label for="wr_18_9" style="padding-inline: 10px;width: 22%;">
                                <input type="checkbox" name="check6[]" id="wr_18_9" value="인스타"<?php echo in_array("인스타", $check6) ? ' checked="checked"' : '' ?> class="required">인스타
                            </label>

                            <label for="wr_18_10" style="padding-inline: 10px;width: 22%;">
                                <input type="checkbox" name="check6[]" id="wr_18_10" value="학원 블로그"<?php echo in_array("학원 블로그", $check6) ? ' checked="checked"' : '' ?> class="required">학원 블로그
                            </label>

                            <label for="wr_18_11" style="padding-inline: 10px;width: 22%;">
                                <input type="checkbox" name="check6[]" id="wr_18_11" value="카페"<?php echo in_array("카페", $check6) ? ' checked="checked"' : '' ?> class="required">카페
                            </label>
                       </td>
                    </tr>

                    <tr>
                        <td class="name_wrap">
                            <label class="name_title" for="wr_19">상담문의</label>
                        </td>
                        <td colspan="4">
                            <textarea name="wr_19" wrap="virtual" class="textarea"></textarea>
                        </td>
                    </tr>

                    <?php if ($member['mb_id']) { ?>
                    <tr>
                        <th class="name_wrap" scope="row"><label for="wr_password">비밀번호</label></th>
                        <td><input type="text" name="wr_20" value="<?php echo $write['wr_20'] ?>" id="wr_20" class="frm_input" size="20"></td>
                    </tr>
                    <?php } ?>
                </tbody>
            </table>

            <?/*php if ($is_category) { ?>
                <div class="form-group">
                    <label for="ca_name">문의종류</label>
                    <div>
                        <select name="ca_name" id="ca_name" required class="form-control required">
                            <option value="">선택하세요</option>
                            <?php foreach($category_list as $v) {?>
                                <option value="<?php echo $v?>"><?php echo $v?></option>
                            <?php }?>
                        </select>
                    </div>
                </div>
            <?php } */?>

            <!--<input type="hidden" name="wr_content" value="내용">-->
            <?php /*?><div class="form-group">
                <label for="wr_content">신청내용</label>
                <div>
                    <textarea id="wr_content" name="wr_content" class="form-control" maxlength="65536" cols="10000" rows="10"><?php echo $wr_content?></textarea>
                </div>
            </div>*/?>

            <?php //for ($i = 0; $is_file && $i < $file_count; $i++) { ?>
                <!--<div class="form-group">
                    <label for="">파일 #<?php //echo $i + 1 ?></label>
                    <div>
                        <input type="file" name="bf_file[]" title="파일첨부 <?php //echo $i + 1 ?> : 용량 <?php //echo $upload_max_filesize ?> 이하만 업로드 가능" class="form-control-file">
                        <?php //if ($is_file_content) { ?>
                            <input type="text" name="bf_content[]" value="<?php //echo ($w == 'u') ? $file[$i]['bf_content'] : ''; ?>" title="파일 설명을 입력해주세요." class="form-control" size="50">
                        <?php //} ?>
                        <?php //if ($w == 'u' && $file[$i]['file']) { ?>
                            <input type="checkbox" id="bf_file_del<?php //echo $i ?>" name="bf_file_del[<?php //echo $i; ?>]" value="1"> <label for="bf_file_del<?php //echo $i ?>"><?php echo $file[$i]['source'] . '(' . $file[$i]['size'] . ')'; ?> 파일 삭제</label>
                        <?php //} ?>
                    </div>
                </div>-->
            <?php //} ?>

            <?//php if ($is_use_captcha) { //자동등록방지  ?>
            <!--<div class="form-group">
                <label for="">자동등록<br/>방지</label>
                <div><?//php echo $captcha_html?></div>
            </div>-->
            <?php //} ?>

            

            <div class="privacy_title">
                ▣ 개인정보 취급방침<br>
                당사는 개인정보취급방침을 통하여 귀하께서 제공하시는 개인정보가 어떠한 용도와 방식으로<br>
                이용되고 있으며 개인정보보호를 위해 어떠한 조치가 취해지고 있는지 알려드립니다.
            </div>

            <div class="privacy-of-use">
                <?//php echo $privacy_html//?>
                <div style="border:1px solid #999999; width:100%; height:140px;">
                    *개인정보의 수집목적 및 이용목적 <br>
                    <br>
                    당사는 이용자 확인, 문의상담 등의 목적으로써 귀하에게 최적의 서비스를 제공하기 위한 목적으로 귀하의 개인정보를 수집·이용하고 있습니다.  수집하는 개인정보 항목에 따른 구체적인 수집목적 및 이용목적은 다음과 같습니다.<br>
                    <br>
                    1.성명, 이메일주소, 연락처, 주소 : 서비스 이용에 따른 본인 확인 절차에 이용 및 상담처리 2.기타문의 및 기타 : 원할한 상담을 위한 참고자료<br>
                </div>
            </div>        

            <div class="privacy-of-use">
                <div style="border:1px solid #999999; width:100%; height:140px;">
                    * 개인정보의 수집<br>
                    <br>
                    1. 당사는 홈페이지를 통한 신청서 작성 시 서비스 이용을 위해 필요한 최소한의 개인정보만을 수집합니다.<br>
                    2. 귀하가 당사의 서비스를 이용하기 위해서는 연락처, 성명 등을 필수적으로 입력하셔야 합니다.<br>
                    <br>
                    그러나, 기타문의, 추가요청사항 같은 선택항목은 이를 입력하지 않더라도 서비스 이용에는 제한이 없습니다.<br>
                </div>
            </div>

            <div class="privacy-of-use">
                <div style="border:1px solid #999999; width:100%; height:150px;">
                    * 개인정보의 보유기간 및 이용기간<br>
                    <br>
                    1. 이용기간 : 귀하의 개인정보는 개인정보침해 신고 조사 및 상담 신청에 대한 답변, 그리고 정부에 의한 후속조치 기간 동안 이용됩니다.<br>
                    <br>
                    2. 보유기간 : 『공공기관의기록물관리에관한법률시행령』제15조제1항에 의거하여, 당사는 귀하의 개인정보의 수집목적 및 이용목적이 달성된 후, 개인정보침해 신고 처리기록 중 중요하다고 판단되는 문서는 3년, 기타 신고 및 상담 처리기록은 컴퓨터파일이 아닌 문서로(off- line)1년 동안 보관합니다.<br>
                </div>
            </div>


            <div class="privacy-of-use-check">
                <label style="font-size: 1rem;"><input type="checkbox" class="required" required/> 개인정보 처리방침에 동의합니다.</label>
            </div>

            <div class="form-footer">
                <button type="submit" id="btn_submit" class="btn_submit btn btn-primary"><i class="fa fa-paper-plane" aria-hidden="true"></i> 신청하기</button>
            </div>

    </section>
</form>

<script type="text/javascript">
    function fwrite_submit(f) {
        let subject = "";
        let content = "";
        $.ajax({
            url: g5_bbs_url + "/ajax.filter.php",
            type: "POST",
            data: {
                "subject": f.wr_subject.value,
                "content": f.wr_content.value
            },
            dataType: "json",
            async: false,
            cache: false,
            success: function(data, textStatus) {
                subject = data.subject;
                content = data.content;
            }
        });

        if (subject) {
            alert("제목에 금지단어('" + subject + "')가 포함되어있습니다");
            f.wr_subject.focus();
            return false;
        }

        if (content) {
            alert("내용에 금지단어('" + content + "')가 포함되어있습니다");
            if (typeof(ed_wr_content) != "undefined")
                ed_wr_content.returnFalse();
            else
                f.wr_content.focus();
            return false;
        }

        // 캡챠 사용시 자바스크립트에서 입력된 캡챠를 검사함
        <?//php echo $captcha_js?>

        //document.getElementById("btn_submit").disabled = "disabled";

        //return true;
    }
</script>
