/* let name = prompt("당신의 이름은?", "");
let height = prompt("당신의 키는?", "");
let weight = prompt("당신의 몸무게는?", "");

let normal_w = (height - 100) * 0.9;
let result = weight >= normal_w - 5 && weight <= normal_w + 5;
result = result ? "적정 체중입니다!" : "적정 체중이 아닙니다!";
document.write(name + "님은 " + result); */


/* let traffic = prompt("당신의 교통비는?", "ex.3000");
let eat = prompt("당신의 식비는?", "ex.6000");
let drink = prompt("당신의 음료비는?", "ex.3000");

let normal = Number(traffic) + Number(eat) + Number(drink);
let result = normal < 10000;
let result1 = 10000 - normal;
let result2 = normal - 10000;

result = result ? result1 + "원 남았습니다! 돈 관리 잘하셨어요!" : result2 + "원 초과! 조금만 더 노력해주세요!";
document.write(result); */

/* let month = prompt("현재는 몇 월입니까?", "0");

if(month >= 9 && <= 11) {
  document.write("독서하기 좋은 가을이네요!");
} else if(month >= 6 && month <= 8) {
  document.write("여행가기 좋은 여름이네요!");
} else if(month >= 3 && month <= 5) {
  document.write("햇살 가득한 봄이네요!");
} else {
  document.write("스키의 계절 겨울이네요!"); 
} */

/* let id = "david";
let pw = "1234";

let user_id = prompt("당신의 아이디를 입력해주세요.");

if(id == user_id) {
  let user_pw = prompt("당신의 비밀번호를 입력해주세요.");  //순서에 유의

  if(pw == user_pw) {
    document.write(user_id + "님 반갑습니다!");
  } else{
    alert("비밀번호가 일치하지 않습니다.");
    location.reload();
  }
} else {
  alert("아이디가 일치하지 않습니다.");
  location.reload();
} */

let site = prompt("네이버, 다음, 네이트, 구글 중 즐겨 사용하는 포털사이트는?", "");
let url;

switch(site) {
  case "구글":url = "https://www.google.com";
  break;
  case "다음":url = "https://www.daum.net";
  break;
  case "네이버":url = "https://www.naver.com";
  break;
  case "네이트":url = "https://www.nate.com";
  break;
  default: alert("보기 중에 없는 사이트 입니다.");
}
if(url) {
  location.href = url;
}
