// let info = navigator.userAgent.toLowerCase();
// let osImg = null;

// if(info.indexOf('windows') >= 0) {
//   osImg = 'windows.png'
// } else if(info.indexOf('macintosh') >= 0) {
//   osImg = 'macintosh.png'
// } else if(info.indexOf('iphone') >= 0) {
//   osImg = 'iphone.png'
// } else if(info.indexOf('android') >= 0) {
//   osImg = 'android.png'
// }

// document.write("<img src=\"/img/1/"+ osImg +"\">", "<br />");


// let scr = screen;
// let sc_w = scr.width;
// let sc_h = scr.height;

// document.write("모니터 해상도 너비: " + sc_w + "px", "<br />");
// document.write("모니터 해상도 높이: " + sc_h + "px", "<br />");



// let menu = ["짜장면", "돈까스", "된장국", "부대찌개", "회덮밥"];
// let menuNum = Math.floor(Math.random()*menu.length);
// let result = menu[menuNum];
// document.write(result);


/* TO DO List */
// let form = document.querySelector('form');
// let input = document.querySelector('input');
// let ul = document.querySelector('ul');

// form.addEventListener('submit', (event) => {
//   event.preventDefault();     // 새로고침이 되지 않게끔 (제출하고 나면 데이터가 사라짐)

//   if(input.value !=='') {     // input 안 값이 공백이 아니라면 (어떤 값이 입력된다면)
//     let li = document.createElement('li');   // li 태그를 생성해라
//     li.innerText = input.value;   // li 안 텍스트는 입력 창 값과 같음.
//     ul.appendChild(li);   // 부모 자식 요소

//     input.value = '';  // 입력 창 공백으로 만들기
//   }
// });



// let count = 0;

// myFnc();

// function myFnc() {
//   count++;
//   document.write("hello" + count, "<br />");
// }

// myFnc();

// let theFnc = function() {
//   count++;
//   document.write("bye" + count, "<br />")
// }

// theFnc();



// let color = ["white", "yellow", "aqua", "purple"];

// let i = 0;
// function changeColor() {
//   i++;
//   if(i >= color.length) {
//     i = 0;
//   }
  
//   let bodyTag = document.getElementById("theBody");
//   bodyTag.style.backgroundColor = color[i];
// }


// function myFnc(name, area) {
//   document.write("안녕하세요. " + name + " 입니다.", "<br />");
//   document.write("사는 곳은 " + area + " 입니다.", "<br />", "<br />");
// }

// myFnc("홍당무", "서울")
// myFnc("깍두기", "부산")



// let rightId = "korea";
// let rightPw = 1234;

// function login(id, pw) {
//   if(id == rightId) {
//     if(pw == rightPw) {
//       document.write(`${id}님 방문을 환영합니다!`);
//     } else {
//       alert("잘못된 비번입니다.");
//     }
//   } else {
//     alert("존재하지 않는 아이디입니다.");
//   }
// }

// let userId = prompt("아이디를 입력하세요!", "");
// let userPw = prompt("비밀번호를 입력하세요!", "");

// login(userId, userPw);



// function sum() {
//   let sum = 0;
//   for(let i = 0; i < arguments.length; i++) {
//     sum += arguments[i];
//   }
//   document.write(sum);
// }

// sum(10, 20, 30);


let a = prompt("수학 점수를 입력해주세요.", "");
let b = prompt("국어 점수를 입력해주세요.", "");
let c = prompt("영어 점수를 입력해주세요.", "");

function sum() {
  let sum = 0;
  for(let i = 0; i < arguments.length; i++) {
    sum += arguments[i];
  }
  document.write(sum);
}

sum(Number(a), Number(b), Number(c));

